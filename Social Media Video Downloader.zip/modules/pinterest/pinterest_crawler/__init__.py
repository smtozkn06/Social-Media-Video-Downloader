from .pinterest_crawler import PinterestCrawler


__version__ = '0.2.0'
